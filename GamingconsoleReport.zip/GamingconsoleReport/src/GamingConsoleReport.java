 public class GamingConsoleReport {

    public static void main(String[] args) {

       
        String[] cities = {"CAPE TOWN", "P0RT ELIZABETH", "PRETORIA"};

       
        String[] consoleTypes = {"PS5", "XBOX", "SWITCH"};

       
        double[][] sales = {
            {1000, 2000, 3000},
            {2000, 3000, 4000},
            {1500, 1100, 1200}
        };

        printStars(80);
        System.out.println("GAMING CONSOLE SALES REPORT BY CITY");
        printStars(80);

        System.out.printf("%-15s", "");
        for (String console : consoleTypes) {
            System.out.printf("%-12s", console);
        }
        System.out.println();

       
        for (int row = 0; row < sales.length; row++) {
            System.out.printf("%-15s", cities[row] + " -->");
            for (int col = 0; col < sales[row].length; col++) {
                System.out.printf("R %-10.0f", sales[row][col]);
            }
            System.out.println();
        }

        printStars(80);
        System.out.println();

     
        printStars(80);
        System.out.println("TOTAL SALES PER CITY");
        printStars(80);

        for (int row = 0; row < sales.length; row++) {
            double total = 0;
            for (int col = 0; col < sales[row].length; col++) {
                total += sales[row][col];
            }
            System.out.printf("%-15s --> R %.1f%n", cities[row], total);
        }

        printStars(80);
    }

    public static void printStars(int count) {
        for (int i = 0; i < count; i++) {
            System.out.print("*");
        }
        System.out.println();
    }
}



